cd /home/galar/compass/software/vomap/src/build
make
cd /home/galar/rock/hwavo/spartan
amake --rebuild
cd /home/galar/rock/hwavo/orogen/spartan/scripts
amake --rebuild
